# Customer database
This database is setup as a PostgreSQL and the script in db-scripts/ folder should be executed as an initialize script when the PostgreSQL database is deployed. The database should be setup as follows:
  * The default password should be Abc.12345 (_if changed the password needs to be changed to access the database in appsettings.json located in the customer-service_)
  * The default database name should be customer_db
